# appEleicao
um sisteminha ainda não terminado para cadastro e gerenciamento de uma eleicao interna de uma empresa
